-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 13, 2012 at 01:53 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `smshub`
--

-- --------------------------------------------------------

--
-- Table structure for table `smshub_contactlist`
--

DROP TABLE IF EXISTS `smshub_contactlist`;
CREATE TABLE IF NOT EXISTS `smshub_contactlist` (
  `contactlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contactlist_name` varchar(250) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`contactlist_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `smshub_contactlist`
--

INSERT INTO `smshub_contactlist` (`contactlist_id`, `user_id`, `contactlist_name`, `date_created`, `last_update_date`, `status`) VALUES
(1, 5, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(2, 5, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(3, 5, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(4, 5, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(5, 5, '', '2012-11-12 00:00:00', '0000-00-00 00:00:00', NULL),
(6, 5, '', '2012-11-12 06:25:22', '0000-00-00 00:00:00', NULL),
(7, 5, '', '2012-11-12 06:26:29', '0000-00-00 00:00:00', NULL),
(8, 1, 'vbvvbv', '0000-00-00 00:00:00', '2012-11-13 02:38:27', NULL),
(9, 23, '65+', '2012-11-13 08:39:12', '2012-11-13 02:38:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `smshub_contacts`
--

DROP TABLE IF EXISTS `smshub_contacts`;
CREATE TABLE IF NOT EXISTS `smshub_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(30) NOT NULL,
  `date_created` date NOT NULL,
  `last_update_date` date NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `smshub_contacts`
--


-- --------------------------------------------------------

--
-- Table structure for table `smshub_groups`
--

DROP TABLE IF EXISTS `smshub_groups`;
CREATE TABLE IF NOT EXISTS `smshub_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '(1-active, 0-inactive)',
  `date_created` date NOT NULL,
  `last_update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `smshub_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `smshub_interface`
--

DROP TABLE IF EXISTS `smshub_interface`;
CREATE TABLE IF NOT EXISTS `smshub_interface` (
  `interface_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `receive_low_warning_type` varchar(50) NOT NULL,
  `balance_threshold` varchar(100) NOT NULL,
  `balance_override` varchar(500) NOT NULL,
  `recive_invoice_email` varchar(500) NOT NULL,
  `invoice_email_override` varchar(500) NOT NULL,
  `messages_to_email` int(11) NOT NULL,
  `message_email_override` varchar(500) NOT NULL,
  PRIMARY KEY (`interface_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `smshub_interface`
--

INSERT INTO `smshub_interface` (`interface_id`, `user_id`, `receive_low_warning_type`, `balance_threshold`, `balance_override`, `recive_invoice_email`, `invoice_email_override`, `messages_to_email`, `message_email_override`) VALUES
(1, 0, 'sms', '0', 's', 'd', 'f', 1, 'g'),
(2, 5, 'sms', 'a', 's', 'd', 'f', 1, 'g'),
(3, 5, 'sms', 'dsf', 'sdaf', 'dsaf', 'sdfds', 1, 'dsfsda');

-- --------------------------------------------------------

--
-- Table structure for table `smshub_sender`
--

DROP TABLE IF EXISTS `smshub_sender`;
CREATE TABLE IF NOT EXISTS `smshub_sender` (
  `sender_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `sender_number` varchar(500) NOT NULL,
  `sender_status` int(11) NOT NULL,
  PRIMARY KEY (`sender_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `smshub_sender`
--

INSERT INTO `smshub_sender` (`sender_id`, `user_id`, `sender_number`, `sender_status`) VALUES
(9, 5, '5555', 0),
(7, 5, '1111111', 1),
(8, 5, '111111', 0);

-- --------------------------------------------------------

--
-- Table structure for table `smshub_users`
--

DROP TABLE IF EXISTS `smshub_users`;
CREATE TABLE IF NOT EXISTS `smshub_users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `mobile_number` varchar(50) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `sms_credits` int(10) unsigned DEFAULT NULL,
  `role_code` varchar(20) DEFAULT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `suburb` varchar(255) DEFAULT NULL,
  `state_code` varchar(10) DEFAULT NULL,
  `country_code` varchar(5) NOT NULL,
  `postcode` varchar(20) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `timezone` varchar(50) NOT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `date_last_updated` datetime DEFAULT NULL,
  `last_login_ip` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `ind_usrs_role` (`role_code`),
  KEY `ind_usrs_cb` (`created_by`),
  KEY `ind_usrs_lub` (`last_updated_by`),
  KEY `ind_country_code` (`country_code`),
  KEY `ind_state_code` (`state_code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `smshub_users`
--

INSERT INTO `smshub_users` (`user_id`, `first_name`, `last_name`, `email`, `mobile_number`, `password`, `company_name`, `sms_credits`, `role_code`, `address_line_1`, `address_line_2`, `city`, `suburb`, `state_code`, `country_code`, `postcode`, `status`, `salt`, `timezone`, `created_by`, `date_created`, `last_updated_by`, `date_last_updated`, `last_login_ip`) VALUES
(1, 'asd', 'asd', 'shakil_bokul@yahoo.co.in', '12312', NULL, '', NULL, NULL, '', NULL, NULL, '', 'New South ', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(2, 'asd', 'asd', 'asdasd@asd.com', '234234234', NULL, 'asd', NULL, NULL, 'asd', NULL, NULL, 'asd', 'New South ', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(3, 'asd', 'asd', 'asdasd@asd.com', '234234234', NULL, '', NULL, NULL, '', NULL, NULL, '', 'New South ', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(4, 'asd', 'asd', 'asdasd@asd.com', '234234234', NULL, '', NULL, NULL, '', NULL, NULL, '', 'New South ', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(5, 'omar', 'asif', 'omar@horoppa.com', '8801815979512', '202cb962ac59075b964b07152d234b70', 'a', NULL, NULL, 'aaaaa', '', NULL, 'a', 'Victoria', '', 'a', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(6, 'aa', 'aa', 'a@horoppa.com', '8801926340611', '38848bb33097d3484b218df5dff3e07c', 'aa', NULL, NULL, 'aadsfasdfsdf', '', NULL, 'aa', 'Northern T', '', 'aa', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(7, 'sad', 'sadsa', 'mamunhowlider@yahoo.com', '01558756176', 'c46375aab1f4f760d861ed71c4e3c7c1', 'fsd', NULL, NULL, 'dsfsd', NULL, NULL, 'sdfsd', 'South Aust', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(8, 'dss', 'sd', 'mamunhowlider10@yahoo.com', '8801558756176', '2c5474c69b2e75a14a1c247740353366', 'safs', NULL, NULL, 'dsfd', NULL, NULL, 'dsfds', 'New South ', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
